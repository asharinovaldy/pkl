SELECT DISTINCT(p.tim_support) AS NAMA
FROM project p
WHERE tgl_mulai BETWEEN "2019-08-01" AND "2019-08-10" 