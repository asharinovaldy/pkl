<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "pkl";

$koneksi = mysqli_connect($host, $user, $pass, $db)
    or die("Koneksi Gagal!");

// $koneksi = mysqli_connect("pfsoft_admin-pc", "praktek", "12345678", "pfsoft")
//     or die("Koneksi Gagal!");
